# Prompt for Arena AI

Upload the extracted folder to a code-capable Arena workspace, then paste:

> Read SKILL.md and use the included scripts to fetch the English captions for this playlist: [paste public playlist URL]. Check access first, enumerate every entry, then harvest and verify. Report the playlist count, successful transcripts, missing IDs and any translated tracks. Never invent missing captions. If YouTube is unreachable, tell me which command to run locally and let me upload the JSON instead. Build the reader from those files, clearly separating the speaker’s words from original devotional writing.

## Local commands

Run from the extracted skill folder with Python 3.10+, `yt-dlp` and `deno` on PATH. Install the Python dependencies in a virtual environment with `python -m pip install -U 'yt-dlp[default]' requests` and install Deno separately. Then run:

```sh
python scripts/preflight.py
python scripts/harvest_all.py 'PUBLIC_PLAYLIST_URL' -o transcripts --workers 4
python scripts/verify_transcripts.py transcripts
```

Check that the manifest is nonempty and compare its IDs with the transcript files. Verification of downloaded files alone does not establish playlist completeness. If the playlist cannot be listed but you have individual video links, run `scripts/playlist.py` on each watch URL without its `list` parameter and pass each resulting manifest to `scripts/harvest.py`. A chat-only Arena session can use uploaded JSON as source material but cannot execute these commands.
